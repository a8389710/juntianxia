<template>
  <van-checkbox v-model="checked">复选框</van-checkbox>



</template>

<script>
  export default {
    data() {
      return {
        checked: true,
      };
    },
  };
</script>

<style scoped>

</style>
